For proper formatting, please include these lines in on the link.css file.

/*Spells*/
span.f1 {color:#000;}
span.f2 {color:#900;}
span.f3 {color:#090;}
span.f4 {color:#009;}