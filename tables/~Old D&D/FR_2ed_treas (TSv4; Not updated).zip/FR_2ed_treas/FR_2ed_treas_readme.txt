The tables that have been developed are provided free of charge.

I have developed these treasure tables based on 2ed which is what I play.  Also, I have added various Forgotten Realms information for local color.  Since these files are pretty much seperate, They should be fairly easy to modify for other worlds or settings.

For Specific Magic Items the table generates a code;
   Examples:
	D-104A-12-x = A Cube of Frost Resistance
	D-108A-10-7 = A (+1) dagger
	D-105-10-2 = Plate mail (-1)
   The code is fairly strait forward
    First is book, where D=DMG (the only one I have put in so far)
    Second is table ID
    Third & fourth are die roll. Where x=no roll required.
  As a DM I use this code to identify magic items by giving
     it to the players instead of the details.
 "locks keep honest dwarves honest, nothing can help a halfling"
	quote by Dalor Ringtearer dwarven troubleshooter.

Additionaly, I have placed them in a subdirectory called FR_2ED_TREAS.  When unzipped this should be a subdirectory within the default \TABLES directory.  I felt this helped organize the various tables that I use with TableSmith.

Michael Long
mlong7_99@yahoo.com



Future plans;
-  The art table is still  a little rough.  I am working on improvements, It is funtional, but it still incomplete in my opinion.
-  Some day I hope to incorporate the treasure tables from the Unearthed arcana.  Unfortunately, I have not typed in those tables yet.



The following files are included.

The following is the text I devised for my category list table.  You may copy and past them or devise your own.

:FR 2ED Treasure
FR_2ed_treas\DMG_Magic
FR_2ed_treas\DMG_MagicWeapons
\FR_misc\z_prayerbook
\FR_misc\z_spellbook
FR_2ed_treas\list_Gems
FR_2ed_treas\list_Art

:FR 2ED Treasure Types
FR_2ed_treas\type_A
FR_2ed_treas\type_B
FR_2ed_treas\type_C
FR_2ed_treas\type_D
FR_2ed_treas\type_E
FR_2ed_treas\type_F
FR_2ed_treas\type_G
FR_2ed_treas\type_H
FR_2ed_treas\type_I
FR_2ed_treas\type_J
FR_2ed_treas\type_K
FR_2ed_treas\type_L
FR_2ed_treas\type_M
FR_2ed_treas\type_N
FR_2ed_treas\type_O
FR_2ed_treas\type_P
FR_2ed_treas\type_Q
FR_2ed_treas\type_R
FR_2ed_treas\type_S
FR_2ed_treas\type_T
FR_2ed_treas\type_U
FR_2ed_treas\type_V
FR_2ed_treas\type_W
FR_2ed_treas\type_X
FR_2ed_treas\type_Y
FR_2ed_treas\type_Z

The following tables are called by the above.
Please note: the root directory for these is the \TABLES directory.
\FR_misc\FR_misc_coinage
\FR_misc\FR_Misc_Books
\FR_misc\FR_Misc_Detail
\FR_misc\FR_Misc_Creatures
\FR_misc\z_prayerbook
\FR_misc\z_spellbook


